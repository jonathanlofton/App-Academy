// Write a method, `digital_root(num)`. It should Sum the digits of a positive
// integer. If it is greater than 10, sum the digits of the resulting number.
// Keep repeating until there is only one digit in the result, called the
// "digital root". **Do not use string conversion within your method.**
//
// You may wish to use a helper function, `digital_root_step(num)` which performs
// one step of the process.


const digitalRoot = (num) => {
  while (num >= 10) {
    const ones = num % 10;
    const remainder = num - ones;
    num = ones + digitalRoot(remainder / 10);
  }
  return num;
};

console.log(digitalRoot(27)); // 9
console.log(digitalRoot(99)); // 9
console.log(digitalRoot(62)); // 8
