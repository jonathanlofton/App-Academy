// return the first n prime numbers.

const isPrime = (num) => {

};



const primes = (n) => {

};

console.log(primes(4));
