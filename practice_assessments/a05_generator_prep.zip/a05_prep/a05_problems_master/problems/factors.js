const factors = (num) => {

};

console.log(factors(10));
