// Write a method that translates a sentence into pig latin. You may want a helper method.
// 'apple' => 'appleay'
// 'pearl' => 'earlpay'
// 'quick' => 'ickquay'



const pigLatin = (sentence) => {

};

console.log(pigLatin("quick"));
console.log(pigLatin("banana"));
console.log(pigLatin("apple"));
console.log(pigLatin("an apple a day helps you learn javascript"));
