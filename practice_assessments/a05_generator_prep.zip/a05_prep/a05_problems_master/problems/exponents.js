const exponent = (b, n) => {

};

console.log(exponent(3,3)); // 27
