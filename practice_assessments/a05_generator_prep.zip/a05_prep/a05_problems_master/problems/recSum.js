//Write a recursive method that returns the sum of all elements in an array
const recSum = (nums) => {

};

console.log(recSum([5,45,7]));
