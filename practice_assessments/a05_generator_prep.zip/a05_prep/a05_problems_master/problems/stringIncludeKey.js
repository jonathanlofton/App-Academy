// Write a recursive method that takes in a string to search and a key string.
// Return true if the string contains all of the characters in the key
// in the same order that they appear in the key.



const stringIncludeKey = (string, key) => {

};


console.log(stringIncludeKey("cadbpc", "abc")); //true
console.log(stringIncludeKey("cba", "abc")); // false
