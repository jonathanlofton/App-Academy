Array.prototype.myReverse = function () {

};

console.log([1,2,3,4].myReverse());
