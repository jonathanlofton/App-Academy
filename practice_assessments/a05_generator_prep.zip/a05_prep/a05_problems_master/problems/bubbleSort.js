Array.prototype.bubbleSort = function() {
  
};

console.log([1,6,3,8,6,5,10].bubbleSort()); // [1,3,5,6,6,8.10]
