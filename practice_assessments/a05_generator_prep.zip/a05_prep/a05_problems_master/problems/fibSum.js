// Implement a method that finds the sum of the first n
// fibonacci numbers recursively. Assume n > 0

const fibSum = (num) => {


};
console.log(fibSum(5)); // [1,1,2,3,5] === 12
