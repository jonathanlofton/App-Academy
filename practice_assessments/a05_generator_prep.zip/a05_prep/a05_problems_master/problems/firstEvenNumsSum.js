//return the sum of the first n even numbers recursively. Assume n > 0

function firstEvenNumbersSum(n) {

}

console.log(firstEvenNumbersSum(3)); //12
