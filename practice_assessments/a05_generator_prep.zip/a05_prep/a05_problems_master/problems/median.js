// Write a method that returns the median of elements in an array
// If the length is even, return the average of the middle two elements

Array.prototype.median = function() {


};

console.log([1,2,3,4,5,6].median()); // 4.5
console.log([1,2,3,4,5].median()); // 3
