Array.prototype.myForEach = function(cb) {

};

console.log([1,2,3,4].myForEach(function(el){
  console.log(el + 1);
}));
