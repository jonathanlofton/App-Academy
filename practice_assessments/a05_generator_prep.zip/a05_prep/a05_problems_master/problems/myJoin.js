// Add your own myJoin to the ArrayClass. If no arg is given,
// set the seperator to "".



Array.prototype.myJoin = function (seperator) {

};

console.log([1,2,3].myJoin());
console.log(["javascript","is","weird"].myJoin(" "));
