  // Write a recursive function that returns the prime factorization of
// a given number. Assume num > 1

const primeFactorization = (num) => {

};


console.log(primeFactorization(12)); // [2,2,3]
