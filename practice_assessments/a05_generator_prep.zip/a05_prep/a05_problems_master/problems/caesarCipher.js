function caesarCipher(str, shift) {

}


console.log(caesarCipher("aaa", 1)); // bbb
console.log(caesarCipher("abc xyz", 3)); // def abc
console.log(caesarCipher("the bear", 3)); // wkh ehdu
