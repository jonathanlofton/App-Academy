const doubler = (array) => {

};

console.log(doubler([1,2,3])); // [2,4,6]
