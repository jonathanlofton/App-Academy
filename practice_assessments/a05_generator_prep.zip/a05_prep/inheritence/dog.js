var Animal = require("./animal.js");
// Dog constructor


module.exports = Dog;
