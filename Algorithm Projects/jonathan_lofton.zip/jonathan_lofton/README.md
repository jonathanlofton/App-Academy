# Dynamic Arrays and Ring Buffer

Refer to the [reading](https://github.com/appacademy/sf-job-search-curriculum/blob/master/algorithms/arrays/arrays_reading.md) for instructions.
After you build your Static Array, Dynamic Array, and Ring Buffer, you will write code to answer QueueWithMax, skeleton and specs provided.

Be sure to rename your project with YOUR firstname_lastname BEFORE zipping!
